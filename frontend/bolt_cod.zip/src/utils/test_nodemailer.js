// // var nodemailer = require('nodemailer');
// import nodemailer from 'nodemailer';

// var transporter = nodemailer.createTransport({
//     // service: 'gmail',
//     // host: "smtp.karunya.edu.in",
//     // host: 'smtp.gmail.com',
//     // port: 587,
//     // secure: false, // true for 465, false for other ports
//     host: 'smtp.ethereal.email',
//     port: 587, // Port for secure SMTP
//     secure: false, // true for 465, false for other ports
//     auth: {
//         user: 'aiyana.gottlieb17@ethereal.email',
//         pass: "hkb8k7kR6DYsjXJ2xs"
//         // pass: 'abfn cdgd swhi ugdj' for praneeth hifi account
//     },
//     logger: true,
//     debug: true,
//     connectionTimeout: 10000, // 10 seconds
// });

// var mailOptions = {
//     from: "aiyana.gottlieb17@ethereal.email",
//     to: "venkatasaishreesriram@gmail.com",
//     subject: "Sending Email using Node.js",
//     text: "That was easy!",
// };
// // console.log(2 + 3);
// transporter.sendMail(mailOptions, function (error, info) {
//         // console.log("sending email");
//         if (error) {
//             console.log(error);
//             // reject(false);
//         } else {
//             console.log("saved the email address:" + mailOptions.to);
//             console.log('Email sent: ' + info.response);
//             // resolve(true);
//         }
//     });

import { Resend } from "resend";

const resend = new Resend("re_3fLV2W1g_PZnn8ZC6u1LgVNTTKJB9g9rQ");
testNodemailer();
export default async function testNodemailer() {
    resend.emails
        .send({
            from: "onboarding@resend.dev",
            to: "venkata.saishree@replicon.com",
            subject: "Test Email from Resend",
            html: "Sent Mail",
        })
        .then((res) => {
            console.log("✅ Email sent successfully", res);
            return true;
        })
        .catch((err) => {
            console.error("❌ Failed to send email:", err);
            return false;
        });
}
